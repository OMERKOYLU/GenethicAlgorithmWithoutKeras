sinif=["Asude","Zeynep","Akif","Melisa","Hatice Kübra" ]
[]